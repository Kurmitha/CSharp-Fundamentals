﻿
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using static System.Formats.Asn1.AsnWriter;

namespace LINQtoObjects
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string? toContinue = string.Empty;   
            do
            {
                DisplayMenu();
                string? input = Console.ReadLine();
                int choice = 0;
                while(int.TryParse(input, out choice) == false || int.Parse(input) < 1 || int.Parse(input) > 18)
                {
                    if(int.TryParse(input, out choice) == false)
                    {
                        Console.WriteLine("Invalid Input");
                    }
                    else
                    {
                        Console.WriteLine("Invalid Choice");
                    }
                    DisplayMenu();
                    input = Console.ReadLine();
                }
                TraineeData traineeData = new TraineeData();
                switch(choice)
                {
                    //Press 1 to Show the list of Trainee Id
                    case 1:
                        IEnumerable<string> allTraineeId = from trainees in traineeData.GetTraineeDetails()
                                                           select trainees.TraineeId;
                        foreach(string id in allTraineeId)
                        {
                            Console.WriteLine(id);
                        }
                        break;

                    //Press 2 to Show the first 3 Trainee Id using Take
                    case 2:
                        IEnumerable<string> firstThreeId = (from trainees in traineeData.GetTraineeDetails()
                                                           select trainees.TraineeId).Take(3);
                        foreach(string id in firstThreeId)
                        {
                            Console.WriteLine(id);
                        }
                        break;

                    // Press 3 to show the last 2 Trainee Id using Skip
                    case 3:
                        List<TraineeDetails> traineeDetails = traineeData.GetTraineeDetails();
                        int count = traineeDetails.Count;
                        IEnumerable<string> lastThreeId = (from trainee in traineeData.GetTraineeDetails()
                                                          select trainee.TraineeId).Skip(count - 2);
                        foreach (string id in lastThreeId)
                        {
                            Console.WriteLine(id);
                        }
                        break;

                    //To show the count of trainee
                    case 4:
                        int traineeCount = (from trainees in traineeData.GetTraineeDetails()
                                                           select trainees).Count();
                        Console.WriteLine($"Total number of trainees: {traineeCount}");
                        break;

                    //Press 5 to show the Trainee Name who are all passed out 2019 or later
                    case 5:
                        IEnumerable<string> traineeNames = from trainees in traineeData.GetTraineeDetails()
                                                            where trainees.YearPassedOut >= 2019
                                                            select trainees.TraineeName;
                        Console.WriteLine("TTrainee Name who are all passed out 2019 or later are as below as follows:");
                        foreach (string name in traineeNames)
                        {
                            Console.WriteLine(name);
                        }
                        break;

                    // Press 6 to show the Trainee Id and Trainee Name by alphabetic order of the trainee name.
                    case 6:
                        var traineeswithIdandName = from trainees in traineeData.GetTraineeDetails()
                                                        orderby trainees.TraineeName
                                                        select new { trainees.TraineeId , trainees.TraineeName};


                        Console.WriteLine("Trainee Name in alphabetical order:");
                        foreach (var trainee in traineeswithIdandName)
                        {
                            Console.WriteLine($"Trainee Id: {trainee.TraineeId} and Trainee Name: {trainee.TraineeName}");
                        }
                        break;

                    // Press 7 to show the
                    // Trainee Id,
                    // Trainee Name,
                    // Topic Name,
                    // Exercise Name,
                    // Mark
                    // who are all scores the more than or equal to 4 mark
                    case 7:
                        var specificDetails = from trainees in traineeData.GetTraineeDetails()
                                      from score in trainees.ScoreDetails
                                      where score.Mark >= 4
                                      select new { trainees.TraineeId, trainees.TraineeName, score.TopicName, score.ExerciseName, score.Mark};
                        foreach (var details in specificDetails)
                        {
                            Console.WriteLine("----------------------------------------------");
                            Console.WriteLine($"ID = {details.TraineeId}  NAME = {details.TraineeName}");
                            Console.WriteLine($"Mark = {details.Mark}\nTopic = {details.TopicName}\nExcercise = {details.ExerciseName}");
                            Console.WriteLine("----------------------------------------------");
                        }
                        break;

                    //Press 8 to show the unique passed out year using distinct
                    case 8:
                        IEnumerable<int> uniqueYears = (from trainees in traineeData.GetTraineeDetails()
                                                               select trainees.YearPassedOut).Distinct();
                        Console.WriteLine("Unique Year Passouts:");
                        foreach (var uniqueEachYear in uniqueYears)
                        {
                            Console.WriteLine(uniqueEachYear);
                        }
                        break;

                    //Press 9 to show the total marks of single user (get the Trainee Id from User),
                    //if Trainee Id does not exist, show the invalid message
                    case 9:
                        Console.WriteLine("Enter the trainee id:");
                        string? userId = Console.ReadLine();
                        bool isValid = false;
                        var specificStudent = from trainee in traineeData.GetTraineeDetails()
                                              where trainee.TraineeId == userId
                                              from score in trainee.ScoreDetails
                                              select new { score.ExerciseName, score.Mark};
                        foreach ( var markDetail in specificStudent)
                        {
                            Console.WriteLine($"{markDetail.ExerciseName} = {markDetail.Mark}");
                            isValid = true;
                        }
                        if(isValid == false)
                        {
                            Console.WriteLine("Invalid Id!");
                        }
                        break;

                    //Press 10 to show the first Trainee Id and Trainee Name
                    case 10:
                        var firstTrainee = traineeData.GetTraineeDetails().First();
                        Console.WriteLine($"First trainee ID: {firstTrainee.TraineeId} First trainee Name: {firstTrainee.TraineeName}");
                        break;

                    // Press 11 to show the last Trainee Id and Trainee Name
                    case 11:
                        var lastTrainee = traineeData.GetTraineeDetails().First();
                        Console.WriteLine($"Last trainee ID: {lastTrainee.TraineeId} Last trainee Name: {lastTrainee.TraineeName}");
                        break;

                    //Press 12 to print the total score of each trainee
                    case 12:
                        var allTraineeScores = from trainee in traineeData.GetTraineeDetails()
                                         from allScoreDetails in trainee.ScoreDetails
                                         group allScoreDetails by trainee.TraineeName;

                        foreach( var score in allTraineeScores)
                        {
                            Console.WriteLine($"Total marks obtained by {score.Key} = {score.Sum(x => x.Mark)}");
                        }
                        break;

                    //Press 13 to show the maximum total score
                    case 13:
                        var maxMark = (from trainee in traineeData.GetTraineeDetails()
                                  let totalMarks = trainee.ScoreDetails.Sum(x=>x.Mark)
                                  select totalMarks).Max();
                        Console.WriteLine($"Maximum Total Score: {maxMark}");
                        
                        break;

                    //Press 14 to show the minimum total score
                    case 14:
                        var minMark = (from trainee in traineeData.GetTraineeDetails()
                                      select trainee.ScoreDetails.Sum(x=>x.Mark)).Min();
                        Console.WriteLine($"Minimum Total Score: {minMark}");
                        break;

                    //Press 15 to show the average of total score
                    case 15:
                        var average = (from trainee in traineeData.GetTraineeDetails()
                                       select trainee.ScoreDetails.Sum(x => x.Mark)).Average();
                        Console.WriteLine($"Average : {average}");
                        break;

                    //Press 16 to show true or false if any one has the more than 40 score using any()
                    case 16:
                        var isRequiredScore = (from trainee in traineeData.GetTraineeDetails()
                                               select trainee.ScoreDetails.Sum(x => x.Mark)).Any(x => x > 40);
                        Console.WriteLine($"Is any one candidate total score is greater than 40 :{isRequiredScore}");
                        break;

                    //Press 17 to show true of false if all of them has the more than 20 using all()
                    case 17:
                        var isAllRequiredScore = (from trainee in traineeData.GetTraineeDetails()
                                                  select trainee.ScoreDetails.Sum(x => x.Mark)).All(x => x > 20);
                        Console.WriteLine($"Does all candidates total score atleast greater than 20 :{isAllRequiredScore}");
                        break;

                    // Press 18 to show
                    // Trainee Id,
                    // Trainee Name,
                    // Topic Name,
                    // Exercise Name
                    // Mark
                    // by show the Trainee Name as descending order
                    // and
                    // then show the Mark as descending order.
                    case 18:
                        var detailSpecific = from trainee in traineeData.GetTraineeDetails()
                                             orderby trainee.TraineeName descending
                                             select new
                                             {
                                                 id = trainee.TraineeId,
                                                 name = trainee.TraineeName,
                                                 scoreDetails =
                                                     from score in trainee.ScoreDetails
                                                     orderby score.Mark descending
                                                     select score
                                             };

                        foreach (var eachTrainee in detailSpecific)
                        {
                            Console.WriteLine("-------------------------------------------------------------------------------");
                            Console.WriteLine($"Id = {eachTrainee.id}\tName = {eachTrainee.name}");
                            foreach(var eachScore in eachTrainee.scoreDetails)
                            {
                                Console.WriteLine($"Topic Name = {eachScore.TopicName}\t Exercise = {eachScore.ExerciseName}\t Mark = {eachScore.Mark}\t");
                            }
                            Console.WriteLine("-------------------------------------------------------------------------------");
                        }
                        break;
                }
                Console.WriteLine("Do you want to continue:");
                toContinue = Console.ReadLine();
                while (!toContinue.Equals("yes") && !toContinue.Equals("no"))
                {
                    Console.WriteLine("Invalid choice!");
                    Console.WriteLine("Do you want to continue? (yes/no)");
                    toContinue = Console.ReadLine().ToLower();
                }
            } while(toContinue == "yes");
            Console.ReadLine();
        }
        public static void DisplayMenu()
        {
            Console.WriteLine("--------------------------------------------------------------------------------------");
            Console.WriteLine("\t\t\tMENU");
            Console.WriteLine("--------------------------------------------------------------------------------------");

            Console.WriteLine("Press 1 to Show the list of Trainee Id \n\n" +
            "Press 2 to Show the first 3 Trainee Id using Take\n\n" +
            "Press 3 to show the last 2 Trainee Id using Skip\n\n" +
            "Press 4 to show the count of Trainee\n\n" +
            "Press 5 to show the Trainee Name who are all passed out 2019 or later\n\n" +
            "Press 6 to show the Trainee Id and Trainee Name by alphabetic order of the trainee name.\n\n" +
            "Press 7 to show the Trainee Id, Trainee Name, Topic Name, Exercise Name and Mark who are all scores\n" +
            "\tthe more than or equal to 4 mark\n\n" +
            "Press 8 to show the unique passed out year using distinct\n\n" +
            "Press 9 to show the total marks of single user (get the Trainee Id from User),\n" +
            "\tif Trainee Id does not exist, show the invalid message\n\n" +
            "Press 10 to show the first Trainee Id and Trainee Name\n\n" +
            "Press 11 to show the last Trainee Id and Trainee Name\n\n" +
            "Press 12 to print the total score of each trainee\n\n" +
            "Press 13 to show the maximum total score\n\n" +
            "Press 14 to show the minimum total score\n\n" +
            "Press 15 to show the average of total score\n\n" +
            "Press 16 to show true or false if any one has the more than 40 score using any()\n\n" +
            "Press 17 to show true of false if all of them has the more than 20 using all()\n\n" +
            "Press 18 to show the Trainee Id, Trainee Name, Topic Name, Exercise Name and Mark\n" +
            "\tby show the Trainee Name as descending order and then show the Mark as descending order.");
            Console.WriteLine("--------------------------------------------------------------------------------------");
            Console.WriteLine("Please enter your choice");
            Console.WriteLine("--------------------------------------------------------------------------------------");
        }


    }
}