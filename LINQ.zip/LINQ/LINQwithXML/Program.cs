﻿
using System.Xml.Linq;

namespace LINQwithXML
{
    class program
    {
        public static void Main(string[] args) 
        {
            //Apply our student structure to XML
            string studentsXML =
                @"<Students>
                    <Student>
                        <Name>Toni</Name>
                        <Age>20</Age>
                        <University>Yale</University>
                        <Semester>5</Semester>
                    </Student>
                    <Student>
                        <Name>Carla</Name>
                        <Age>17</Age>
                        <University>Yale</University>
                        <Semester>3</Semester>
                    </Student>
                    <Student>
                        <Name>Leyla</Name>
                        <Age>23</Age>
                        <University>Beijing Tech</University>
                        <Semester>7</Semester>
                    </Student>
                    <Student>
                        <Name>Frank</Name>
                        <Age>22</Age>
                        <University>Beijing Tech</University>
                        <Semester>6</Semester>
                    </Student>
                </Students>";

            XDocument studentsXdoc = new XDocument();
            studentsXdoc = XDocument.Parse(studentsXML);

            //List all the students in the XML
            Console.WriteLine("Students Details:");
            var students = from student in studentsXdoc.Descendants("Student")
                           select new
                           {
                               Name = student.Element("Name").Value,
                               Age = student.Element("Age").Value,
                               University = student.Element("University").Value,
                               Semester = student.Element("Semester").Value
                           };
            foreach( var student in students)
            {
                Console.WriteLine("Student {0} with age {1} from University {2} is in {3} Semester",student.Name, student.Age, student.University, student.Semester);
            }

            //Sort student by their age
            Console.WriteLine("Sort Students by their Age:");
            var studentbyAge = from student in students orderby student.Age select student;

            foreach( var student in studentbyAge)
            {
                Console.WriteLine("Student {0} with age {1} from Unviersity {2}", student.Name, student.Age,student.University);
            }

        }
    } 
}