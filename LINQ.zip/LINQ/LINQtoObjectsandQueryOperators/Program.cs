﻿
namespace LinQtoObjectsandQueryOperators
{
    class Program
    {
        public static void Main(string[] args)
        {
            UniversityManager universityManager = new UniversityManager();
            universityManager.MaleStudents();
            universityManager.FemaleStudents();
            universityManager.SortStudentbyAge();
            universityManager.AllStudentfromBeijingTech();
            Console.WriteLine("Enter the ID(1/2) of the university to get student details:");
            string id = Console.ReadLine();
            int universityId = int.Parse(id);
            universityManager.GetStudentsbyID(universityId);
            universityManager.GetStudentwithUniversityName();

        }
    }
    class UniversityManager
    {
        List<University> universities;
        List<Student> students;
        public UniversityManager()
        {
            universities = new List<University>();
            students = new List<Student>();

            universities.Add(new University { Id = 1, Name = "Yale"});
            universities.Add(new University { Id = 2, Name = "Beijing Tech"});

            students.Add(new Student { Id = 1, Name = "James", Age = 19, Gender = "male", UniversityId = 1 });
            students.Add(new Student { Id = 1, Name = "John", Age = 23, Gender = "male", UniversityId = 1 });
            students.Add(new Student { Id = 1, Name = "Daniel", Age = 18, Gender = "male", UniversityId = 2 });
            students.Add(new Student { Id = 1, Name = "Jessy", Age = 21, Gender = "female", UniversityId = 2 });
            students.Add(new Student { Id = 1, Name = "Diana", Age = 22, Gender = "female", UniversityId = 1 });
        }

        public void MaleStudents()
        {
            IEnumerable<Student> maleStudents = from student in students where student.Gender == "male" select student;
            Console.WriteLine("Male Students:");
            foreach (Student student in maleStudents)
            {
                student.Print();
            }
            Console.WriteLine("*******************************************************************************");
        }
        public void FemaleStudents()
        {
            IEnumerable<Student> femaleStudents = from student in students where student.Gender == "female" select student;
            Console.WriteLine("Female Students:");
            foreach (Student student in femaleStudents)
            {
                student.Print();
            }
            Console.WriteLine("*******************************************************************************");
        }
        public void SortStudentbyAge()
        {
            var sortedStudent = from student in students orderby student.Age select student;
            Console.WriteLine("Sorted Students:");
            foreach (var student in sortedStudent)
            {
                student.Print();
            }
            Console.WriteLine("*******************************************************************************");
        }
        public void AllStudentfromBeijingTech()
        {
            IEnumerable<Student> bjtStudent = from student in students
                                              join university in universities
                                              on student.UniversityId equals university.Id
                                              where university.Name == "Beijing Tech"
                                              select student;
            Console.WriteLine("Student from Beijing Tech:");
            foreach(var student in bjtStudent)
            {
                student.Print();
            }
            Console.WriteLine("*******************************************************************************");
        }
        public void GetStudentsbyID(int id)
        {
            IEnumerable<Student> studentbyId = from student in students
                                              join university in universities
                                              on student.UniversityId equals university.Id
                                              where university.Id == id
                                              select student;
            Console.WriteLine("Student from {0} University:", id);
            foreach (var student in studentbyId)
            {
                student.Print();
            }
            Console.WriteLine("*******************************************************************************");
        }
        public void GetStudentwithUniversityName()
        {
            var studentwithUniversityName = from student in students
                      join university in universities
                      on student.UniversityId equals university.Id
                      orderby student.Name
                      select new { StudentName = student.Name, UniversityName = university.Name };
            Console.WriteLine("Student with University Name:");
            foreach (var student in studentwithUniversityName)
            {
                Console.WriteLine("Student {0} from University {1}", student.StudentName, student.UniversityName);
            }
            Console.WriteLine("*******************************************************************************");
        }
    }
    class University
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public void Print()
        {
            Console.WriteLine("Universities {0} with id {1}", Name, Id);
        }
    }
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public int UniversityId { get; set; }
        public void Print()
        {
            Console.WriteLine("Student {0} with Id {1}, Gender {2} and Age {3} from university with Id {4}",Name,Id,Gender,Age,UniversityId);
        }
    }
}