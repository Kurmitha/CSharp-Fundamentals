﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.Linq;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LINQtoSQL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        LinqtoSqlDataClassesDataContext dataContext;
        
        public MainWindow()
        {
            InitializeComponent();
            string connection = ConfigurationManager.ConnectionStrings["LINQtoSQL.Properties.Settings.LearningC_ConnectionString"].ConnectionString;
            dataContext = new LinqtoSqlDataClassesDataContext(connection);
            //InsertUniversity();
            //InsertStudent();
            //InsertLecture();
            //InsertStudentLectureAssociations();
            //GetUniversityOfCarla();
            //GetLectureOfCarla();
            //GetAllLecturesFromBeijingTech();
            // UpdateToni();
            DeleteJame();
        }
        public void InsertUniversity()
        {
            
            University yale = new University();
            yale.Name = "Yale";
            dataContext.Universities.InsertOnSubmit(yale);

            University bjt = new University();
            bjt.Name = "Beijing Tech";
            dataContext.Universities.InsertOnSubmit(bjt);

            dataContext.SubmitChanges();
            MainDataGrid.ItemsSource = dataContext.Universities;
        }
        public void InsertStudent()
        {
            University yale = dataContext.Universities.First(un => un.Name.Equals("Yale"));
            University bjt = dataContext.Universities.First(un => un.Name.Equals("Beijing Tech"));
            List<Student> students = new List<Student>();
            students.Add(new Student { Name = "Angel", Gender = "female", University = yale });
            students.Add(new Student { Name = "John", Gender = "male", University = yale });
            students.Add(new Student { Name = "Carla", Gender = "female", University = bjt });
            students.Add(new Student { Name = "Sam", Gender = "male", University = yale });
            students.Add(new Student { Name = "William", Gender = "female", University = bjt });
            students.Add(new Student { Name = "Diana", Gender = "female", University = yale });

            dataContext.Students.InsertAllOnSubmit(students);
            dataContext.SubmitChanges();
            MainDataGrid.ItemsSource = dataContext.Students;
        }
        public void InsertLecture()
        {
            List<Lecture> lectures = new List<Lecture>();
            lectures.Add(new Lecture { Name = "Science" });
            lectures.Add(new Lecture { Name = "Maths" });
            lectures.Add(new Lecture { Name = "Computer Science" });
            lectures.Add(new Lecture { Name = "Biology" });
            dataContext.Lectures.InsertAllOnSubmit(lectures);
            dataContext.SubmitChanges();
            MainDataGrid.ItemsSource = lectures;
        }
        public void InsertStudentLectureAssociations()
        {
            Student Angel = dataContext.Students.First(st => st.Name.Equals("Angel"));
            Student Carla = dataContext.Students.First(st => st.Name.Equals("Carla"));
            Student Sam = dataContext.Students.First(st => st.Name.Equals("Sam"));
            Student John = dataContext.Students.First(st => st.Name.Equals("John"));

            Lecture Maths = dataContext.Lectures.First(lc => lc.Name.Equals("Maths"));
            Lecture Science = dataContext.Lectures.First(lc => lc.Name.Equals("Science"));
            Lecture Biology = dataContext.Lectures.First(lc => lc.Name.Equals("Biology"));

            dataContext.StudentLectures.InsertOnSubmit(new StudentLecture { Student = Carla, Lecture = Maths });
            dataContext.StudentLectures.InsertOnSubmit(new StudentLecture { Student = Angel, Lecture = Maths });
            dataContext.StudentLectures.InsertOnSubmit(new StudentLecture { Student = Sam, Lecture = Biology });
            dataContext.StudentLectures.InsertOnSubmit(new StudentLecture { Student = John, Lecture = Science });

            dataContext.SubmitChanges();
            MainDataGrid.ItemsSource = dataContext.StudentLectures;
        }

        public void GetUniversityOfCarla()
        {
            Student Carla = dataContext.Students.First(st => st.Name.Equals("Carla"));
            University carlaUniversity = Carla.University;
            List<University> universities = new List<University>();
            universities.Add(carlaUniversity);

            MainDataGrid.ItemsSource = universities;
        }

        public void GetLectureOfCarla()
        {
            Student Carla = dataContext.Students.First(st => st.Name.Equals("Carla"));
            var carlaLectures = from sl in Carla.StudentLectures select sl.Lecture;
            MainDataGrid.ItemsSource = carlaLectures;
        }
        public void GetAllLecturesFromBeijingTech()
        {
            var lecturesFromBeijingTech = from sl in dataContext.StudentLectures
                                          join student in dataContext.Students on sl.StudentId equals student.Id
                                          where student.University.Name == "Beijing Tech"
                                          select sl.Lecture;

            MainDataGrid.ItemsSource = lecturesFromBeijingTech;
        }
        public void UpdateToni()
        {
            Student Toni = dataContext.Students.FirstOrDefault(st => st.Name == "Toni");

            Toni.Name = "Antonio";

            dataContext.SubmitChanges();

            MainDataGrid.ItemsSource = dataContext.Students;
        }

        public void DeleteJame()
        {
            Student Jame = dataContext.Students.FirstOrDefault(st => st.Name == "Jame");
            dataContext.Students.DeleteOnSubmit(Jame);
            dataContext.SubmitChanges();

            MainDataGrid.ItemsSource = dataContext.Students;
        }
    }
}
